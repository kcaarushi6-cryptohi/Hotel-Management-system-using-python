def start():
    while True:
        print()
        print("====================================")
        print("       RECEPTIONIST MENU")
        print("====================================")
        print("1. Register New Guest")
        print("2. Make a Booking  (auto room pick)")
        print("3. Check In Guest")
        print("4. Check Out Guest  (late fee if after 12pm)")
        print("5. Cancel a Booking")
        print("6. View Available Rooms")
        print("7. View Guest History")
        print("8. Print Receipt")
        print("0. Logout")
        print("====================================")

        choice = input("Enter your choice: ")

        if choice == "1":
            register_guest()
        elif choice == "2":
            make_booking()
        elif choice == "3":
            check_in()
        elif choice == "4":
            check_out()
        elif choice == "5":
            cancel_booking()
        elif choice == "6":
            view_available_rooms()
        elif choice == "7":
            view_guest_history()
        elif choice == "8":
            print_receipt()
        elif choice == "0":
            print("Logged out. Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")

def register_guest():
    print()
    print("---- Register New Guest ----")
    f = open("guests.txt", "r")
    lines = f.readlines()
    f.close()
    guest_number = len(lines) + 1
    guest_id = "G" + str(guest_number).zfill(3)
    print("New Guest ID:", guest_id)
    name = input("Enter guest name: ")
    phone = input("Enter phone number: ")
    if name == "":
        print("Name cannot be empty.")
        return
    if phone == "":
        print("Phone cannot be empty.")
        return
    new_line = guest_id + "," + name + "," + phone + "\n"
    f = open("guests.txt", "a")
    f.write(new_line)
    f.close()
    print("Guest", name, "registered with ID:", guest_id)

def make_booking():
    print()
    print("---- Make a Booking ----")
    guest_id = input("Enter Guest ID (e.g. G001): ")
    f = open("guests.txt", "r")
    guests = f.readlines()
    f.close()
    guest_found = False
    guest_name = ""
    for guest in guests:
        parts = guest.strip().split(",")
        if parts[0] == guest_id:
            guest_found = True
            guest_name = parts[1]
            break
    if guest_found == False:
        print("Guest ID not found. Please register the guest first.")
        return
    print("Guest:", guest_name)
    print()
    print("Room Types available:")
    print("  Single - Rs 150/night")
    print("  Double - Rs 250/night")
    print("  Suite  - Rs 500/night")
    room_type = input("Enter room type you want: ")

    # UNIQUE FEATURE 1: AUTO ROOM ASSIGNMENT
    f = open("rooms.txt", "r")
    rooms = f.readlines()
    f.close()
    assigned_room = None
    room_price = 0
    for room in rooms:
        parts = room.strip().split(",")
        if parts[1] == room_type and parts[3] == "available":
            assigned_room = parts[0]
            room_price = int(parts[2])
            break
    if assigned_room == None:
        print("Sorry, no", room_type, "rooms are available right now.")
        return
    print("Room automatically assigned:", assigned_room)

    checkin = input("Enter check-in date (e.g. 2025-07-01): ")
    checkout = input("Enter check-out date (e.g. 2025-07-04): ")
    nights = input("Enter number of nights: ")
    if nights.isdigit() == False:
        print("Nights must be a number.")
        return
    nights = int(nights)
    total = room_price * nights
    print()
    print("---- Booking Summary ----")
    print("Guest  :", guest_name)
    print("Room   :", assigned_room, "(", room_type, ")")
    print("Nights :", nights)
    print("Total  : Rs", total)
    confirm = input("\nConfirm booking? (yes / no): ")
    if confirm != "yes":
        print("Booking cancelled.")
        return
    f = open("bookings.txt", "r")
    existing = f.readlines()
    f.close()
    booking_number = len(existing) + 1
    booking_id = "B" + str(booking_number).zfill(3)
    new_line = booking_id + "," + guest_id + "," + assigned_room + "," + checkin + "," + checkout + "," + str(nights) + "," + str(total) + ",reserved\n"
    f = open("bookings.txt", "a")
    f.write(new_line)
    f.close()
    update_room_status(assigned_room, "occupied")
    print("Booking", booking_id, "created successfully!")

def check_in():
    print()
    print("---- Check In ----")
    booking_id = input("Enter Booking ID (e.g. B001): ")
    f = open("bookings.txt", "r")
    bookings = f.readlines()
    f.close()
    new_bookings = []
    found = False
    for booking in bookings:
        parts = booking.strip().split(",")
        if parts[0] == booking_id:
            found = True
            if parts[7] != "reserved":
                print("This booking is already", parts[7], ". Cannot check in.")
                return
            parts[7] = "checked_in"
            new_bookings.append(",".join(parts) + "\n")
            print("Guest checked in to Room", parts[2], ". Have a nice stay!")
        else:
            new_bookings.append(booking)
    if found == False:
        print("Booking ID not found.")
        return
    f = open("bookings.txt", "w")
    f.writelines(new_bookings)
    f.close()

def check_out():
    print()
    print("---- Check Out ----")
    booking_id = input("Enter Booking ID (e.g. B001): ")
    f = open("bookings.txt", "r")
    bookings = f.readlines()
    f.close()
    found = False
    booking_info = []
    for booking in bookings:
        parts = booking.strip().split(",")
        if parts[0] == booking_id:
            found = True
            booking_info = parts
            break
    if found == False:
        print("Booking ID not found.")
        return
    if booking_info[7] != "checked_in":
        print("Guest is not checked in. Current status:", booking_info[7])
        return
    base_total = int(booking_info[6])

    # UNIQUE FEATURE 2: LATE CHECKOUT FEE
    print()
    print("Standard checkout time is 12:00 PM.")
    checkout_hour = input("Enter current checkout hour (0-23, e.g. 14 for 2pm): ")
    if checkout_hour.isdigit() == False:
        print("Please enter a valid hour number.")
        return
    checkout_hour = int(checkout_hour)
    late_fee = 0
    if checkout_hour > 12:
        hours_late = checkout_hour - 12
        late_fee = hours_late * 50
        print("Guest is", hours_late, "hour(s) late. Late fee: Rs", late_fee)
    else:
        print("On time checkout. No late fee.")
    grand_total = base_total + late_fee
    print()
    print("---- Checkout Summary ----")
    print("Booking ID   :", booking_id)
    print("Room         :", booking_info[2])
    print("Base Charges : Rs", base_total)
    print("Late Fee     : Rs", late_fee)
    print("GRAND TOTAL  : Rs", grand_total)
    confirm = input("\nConfirm checkout? (yes / no): ")
    if confirm != "yes":
        print("Checkout cancelled.")
        return
    new_bookings = []
    for booking in bookings:
        parts = booking.strip().split(",")
        if parts[0] == booking_id:
            parts[7] = "checked_out"
            parts[6] = str(grand_total)
            new_bookings.append(",".join(parts) + "\n")
        else:
            new_bookings.append(booking)
    f = open("bookings.txt", "w")
    f.writelines(new_bookings)
    f.close()
    update_room_status(booking_info[2], "available")
    f = open("cleaning.txt", "a")
    f.write(booking_info[2] + ",needs_cleaning\n")
    f.close()
    print("Checkout complete! Room", booking_info[2], "is now free.")
    want_receipt = input("\nPrint receipt? (yes / no): ")
    if want_receipt == "yes":
        show_receipt(booking_id, booking_info[1], booking_info[2],
                     booking_info[3], booking_info[4], booking_info[5],
                     base_total, late_fee, grand_total)

def cancel_booking():
    print()
    print("---- Cancel Booking ----")
    booking_id = input("Enter Booking ID to cancel: ")
    f = open("bookings.txt", "r")
    bookings = f.readlines()
    f.close()
    new_bookings = []
    found = False
    for booking in bookings:
        parts = booking.strip().split(",")
        if parts[0] == booking_id:
            found = True
            if parts[7] == "checked_in":
                print("Cannot cancel. Guest is already checked in. Use checkout instead.")
                return
            parts[7] = "cancelled"
            new_bookings.append(",".join(parts) + "\n")
            update_room_status(parts[2], "available")
            print("Booking", booking_id, "cancelled. Room", parts[2], "is now available.")
        else:
            new_bookings.append(booking)
    if found == False:
        print("Booking ID not found.")
        return
    f = open("bookings.txt", "w")
    f.writelines(new_bookings)
    f.close()

def view_available_rooms():
    print()
    print("---- Available Rooms ----")
    f = open("rooms.txt", "r")
    rooms = f.readlines()
    f.close()
    count = 0
    for room in rooms:
        parts = room.strip().split(",")
        if parts[3] == "available":
            print("Room:", parts[0], "| Type:", parts[1], "| Price: Rs", parts[2], "per night")
            count = count + 1
    if count == 0:
        print("No rooms available at the moment.")
    else:
        print("\nTotal available rooms:", count)

def view_guest_history():
    print()
    print("---- Guest Booking History ----")
    guest_id = input("Enter Guest ID: ")
    f = open("bookings.txt", "r")
    bookings = f.readlines()
    f.close()
    found = False
    for booking in bookings:
        parts = booking.strip().split(",")
        if parts[1] == guest_id:
            found = True
            print("Booking:", parts[0], "| Room:", parts[2],
                  "| Check-in:", parts[3], "| Check-out:", parts[4],
                  "| Total: Rs", parts[6], "| Status:", parts[7])
    if found == False:
        print("No bookings found for Guest ID:", guest_id)

def print_receipt():
    print()
    print("---- Print Receipt ----")
    booking_id = input("Enter Booking ID: ")
    f = open("bookings.txt", "r")
    bookings = f.readlines()
    f.close()
    found = False
    for booking in bookings:
        parts = booking.strip().split(",")
        if parts[0] == booking_id:
            found = True
            total = int(parts[6])
            show_receipt(booking_id, parts[1], parts[2],
                         parts[3], parts[4], parts[5],
                         total, 0, total)
            break
    if found == False:
        print("Booking not found.")

# UNIQUE FEATURE 3: TEXT RECEIPT
def show_receipt(booking_id, guest_id, room_id, checkin, checkout, nights, base, late_fee, grand_total):
    print()
    print("==========================================")
    print("       STAYEASE HOTEL - RECEIPT")
    print("==========================================")
    print("Booking ID   :", booking_id)
    print("Guest ID     :", guest_id)
    print("Room         :", room_id)
    print("Check-in     :", checkin)
    print("Check-out    :", checkout)
    print("Nights       :", nights)
    print("------------------------------------------")
    print("Room Charges : Rs", base)
    print("Late Fee     : Rs", late_fee)
    print("------------------------------------------")
    print("TOTAL PAID   : Rs", grand_total)
    print("==========================================")
    print("  Thank you for staying at StayEase!")
    print("==========================================")
    filename = "receipt_" + booking_id + ".txt"
    f = open(filename, "w")
    f.write("==========================================\n")
    f.write("       STAYEASE HOTEL - RECEIPT\n")
    f.write("==========================================\n")
    f.write("Booking ID   : " + booking_id + "\n")
    f.write("Guest ID     : " + guest_id + "\n")
    f.write("Room         : " + room_id + "\n")
    f.write("Check-in     : " + checkin + "\n")
    f.write("Check-out    : " + checkout + "\n")
    f.write("Nights       : " + str(nights) + "\n")
    f.write("------------------------------------------\n")
    f.write("Room Charges : Rs " + str(base) + "\n")
    f.write("Late Fee     : Rs " + str(late_fee) + "\n")
    f.write("------------------------------------------\n")
    f.write("TOTAL PAID   : Rs " + str(grand_total) + "\n")
    f.write("==========================================\n")
    f.write("  Thank you for staying at StayEase!\n")
    f.write("==========================================\n")
    f.close()
    print("\nReceipt saved as:", filename)

def update_room_status(room_id, new_status):
    f = open("rooms.txt", "r")
    rooms = f.readlines()
    f.close()
    new_rooms = []
    for room in rooms:
        parts = room.strip().split(",")
        if parts[0] == room_id:
            parts[3] = new_status
            new_rooms.append(",".join(parts) + "\n")
        else:
            new_rooms.append(room)
    f = open("rooms.txt", "w")
    f.writelines(new_rooms)
    f.close()