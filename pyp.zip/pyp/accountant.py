def start():
    while True:
        print()
        print("====================================")
        print("        ACCOUNTANT MENU")
        print("====================================")
        print("1. Record a Payment")
        print("2. View All Payments")
        print("3. View Outstanding Balances")
        print("4. Monthly Income Summary")
        print("0. Logout")
        print("====================================")

        choice = input("Enter your choice: ")

        if choice == "1":
            record_payment()
        elif choice == "2":
            view_payments()
        elif choice == "3":
            view_outstanding()
        elif choice == "4":
            monthly_summary()
        elif choice == "0":
            print("Logged out. Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")

def record_payment():
    print()
    print("---- Record Payment ----")
    f = open("bookings.txt", "r")
    bookings = f.readlines()
    f.close()
    if len(bookings) == 0:
        print("No bookings found.")
        return
    print("Current Bookings:")
    for booking in bookings:
        parts = booking.strip().split(",")
        print("  Booking:", parts[0], "| Guest:", parts[1], "| Total: Rs", parts[6], "| Status:", parts[7])
    booking_id = input("\nEnter Booking ID to record payment for: ")
    booking_found = False
    booking_total = 0
    for booking in bookings:
        parts = booking.strip().split(",")
        if parts[0] == booking_id:
            booking_found = True
            booking_total = int(parts[6])
            break
    if booking_found == False:
        print("Booking ID not found.")
        return
    print("Total amount due: Rs", booking_total)
    amount = input("Enter amount received (Rs): ")
    if amount.isdigit() == False:
        print("Amount must be a number.")
        return
    f = open("payments.txt", "r")
    existing = f.readlines()
    f.close()
    payment_number = len(existing) + 1
    payment_id = "PAY" + str(payment_number).zfill(3)
    new_line = payment_id + "," + booking_id + "," + amount + "\n"
    f = open("payments.txt", "a")
    f.write(new_line)
    f.close()
    print("Payment", payment_id, "recorded. Rs", amount, "received.")

def view_payments():
    print()
    print("---- All Payments ----")
    f = open("payments.txt", "r")
    payments = f.readlines()
    f.close()
    if len(payments) == 0:
        print("No payments recorded yet.")
        return
    total = 0
    for payment in payments:
        parts = payment.strip().split(",")
        print("Payment:", parts[0], "| Booking:", parts[1], "| Amount: Rs", parts[2])
        total = total + int(parts[2])
    print()
    print("Total collected: Rs", total)

def view_outstanding():
    print()
    print("---- Outstanding Balances ----")
    f = open("bookings.txt", "r")
    bookings = f.readlines()
    f.close()
    f = open("payments.txt", "r")
    payments = f.readlines()
    f.close()
    if len(bookings) == 0:
        print("No bookings found.")
        return
    any_outstanding = False
    for booking in bookings:
        b_parts = booking.strip().split(",")
        booking_id = b_parts[0]
        total_due = int(b_parts[6])
        status = b_parts[7]
        if status == "cancelled":
            continue
        total_paid = 0
        for payment in payments:
            p_parts = payment.strip().split(",")
            if p_parts[1] == booking_id:
                total_paid = total_paid + int(p_parts[2])
        balance = total_due - total_paid
        if balance > 0:
            any_outstanding = True
            print("Booking:", booking_id, "| Guest:", b_parts[1],
                  "| Total Due: Rs", total_due, "| Paid: Rs", total_paid,
                  "| BALANCE: Rs", balance)
    if any_outstanding == False:
        print("No outstanding balances. All bookings are fully paid!")

def monthly_summary():
    print()
    print("---- Monthly Income Summary ----")
    month = input("Enter month to check (e.g. 2025-07): ")
    f = open("bookings.txt", "r")
    bookings = f.readlines()
    f.close()
    f = open("payments.txt", "r")
    payments = f.readlines()
    f.close()
    bookings_this_month = []
    for booking in bookings:
        parts = booking.strip().split(",")
        if parts[3].startswith(month):
            bookings_this_month.append(booking)
    reserved_count = 0
    checked_in_count = 0
    checked_out_count = 0
    cancelled_count = 0
    for booking in bookings_this_month:
        parts = booking.strip().split(",")
        if parts[7] == "reserved":
            reserved_count = reserved_count + 1
        elif parts[7] == "checked_in":
            checked_in_count = checked_in_count + 1
        elif parts[7] == "checked_out":
            checked_out_count = checked_out_count + 1
        elif parts[7] == "cancelled":
            cancelled_count = cancelled_count + 1
    booking_ids_this_month = []
    for booking in bookings_this_month:
        booking_ids_this_month.append(booking.split(",")[0])
    total_income = 0
    for payment in payments:
        parts = payment.strip().split(",")
        if parts[1] in booking_ids_this_month:
            total_income = total_income + int(parts[2])
    print()
    print("Month          :", month)
    print("Total Bookings :", len(bookings_this_month))
    print("  Reserved     :", reserved_count)
    print("  Checked In   :", checked_in_count)
    print("  Checked Out  :", checked_out_count)
    print("  Cancelled    :", cancelled_count)
    print("Total Income   : Rs", total_income)