def start():
    while True:
        print()
        print("====================================")
        print("         MANAGER MENU")
        print("====================================")
        print("1. View All Rooms")
        print("2. Add a Room")
        print("3. Remove a Room")
        print("4. View All Guests")
        print("5. View All Bookings")
        print("6. View Summary Report")
        print("0. Logout")
        print("====================================")

        choice = input("Enter your choice: ")

        if choice == "1":
            view_rooms()
        elif choice == "2":
            add_room()
        elif choice == "3":
            remove_room()
        elif choice == "4":
            view_guests()
        elif choice == "5":
            view_bookings()
        elif choice == "6":
            view_summary()
        elif choice == "0":
            print("Logged out. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a number from the menu.")

def view_rooms():
    print()
    print("---- All Rooms ----")
    f = open("rooms.txt", "r")
    lines = f.readlines()
    f.close()
    if len(lines) == 0:
        print("No rooms found.")
        return
    for line in lines:
        line = line.strip()
        parts = line.split(",")
        print("Room ID:", parts[0], "| Type:", parts[1], "| Price: Rs", parts[2], "| Status:", parts[3])

def add_room():
    print()
    print("---- Add New Room ----")
    f = open("rooms.txt", "r")
    lines = f.readlines()
    f.close()
    room_number = len(lines) + 1
    room_id = "R" + str(room_number).zfill(3)
    print("New Room ID will be:", room_id)
    room_type = input("Enter room type (Single / Double / Suite): ")
    price = input("Enter price per night (Rs): ")
    if price.isdigit() == False:
        print("Price must be a number. Room not added.")
        return
    new_line = room_id + "," + room_type + "," + price + ",available\n"
    f = open("rooms.txt", "a")
    f.write(new_line)
    f.close()
    print("Room", room_id, "added successfully!")

def remove_room():
    print()
    print("---- Remove a Room ----")
    view_rooms()
    room_id = input("\nEnter Room ID to remove (e.g. R001): ")
    f = open("rooms.txt", "r")
    lines = f.readlines()
    f.close()
    new_lines = []
    found = False
    for line in lines:
        parts = line.strip().split(",")
        if parts[0] == room_id:
            found = True
        else:
            new_lines.append(line)
    if found == False:
        print("Room ID not found.")
        return
    f = open("rooms.txt", "w")
    f.writelines(new_lines)
    f.close()
    print("Room", room_id, "removed successfully!")

def view_guests():
    print()
    print("---- All Guests ----")
    f = open("guests.txt", "r")
    lines = f.readlines()
    f.close()
    if len(lines) == 0:
        print("No guests registered yet.")
        return
    for line in lines:
        line = line.strip()
        parts = line.split(",")
        print("Guest ID:", parts[0], "| Name:", parts[1], "| Phone:", parts[2])

def view_bookings():
    print()
    print("---- All Bookings ----")
    f = open("bookings.txt", "r")
    lines = f.readlines()
    f.close()
    if len(lines) == 0:
        print("No bookings found.")
        return
    for line in lines:
        line = line.strip()
        parts = line.split(",")
        print("Booking:", parts[0], "| Guest:", parts[1], "| Room:", parts[2],
              "| Check-in:", parts[3], "| Check-out:", parts[4],
              "| Total: Rs", parts[6], "| Status:", parts[7])

def view_summary():
    print()
    print("---- Summary Report ----")
    f = open("rooms.txt", "r")
    rooms = f.readlines()
    f.close()
    total_rooms = len(rooms)
    available_count = 0
    occupied_count = 0
    for room in rooms:
        parts = room.strip().split(",")
        if parts[3] == "available":
            available_count = available_count + 1
        elif parts[3] == "occupied":
            occupied_count = occupied_count + 1
    f = open("bookings.txt", "r")
    bookings = f.readlines()
    f.close()
    total_bookings = len(bookings)
    f = open("payments.txt", "r")
    payments = f.readlines()
    f.close()
    total_income = 0
    for payment in payments:
        parts = payment.strip().split(",")
        total_income = total_income + int(parts[2])
    print("Total Rooms     :", total_rooms)
    print("Available Rooms :", available_count)
    print("Occupied Rooms  :", occupied_count)
    print("Total Bookings  :", total_bookings)
    print("Total Income    : Rs", total_income)