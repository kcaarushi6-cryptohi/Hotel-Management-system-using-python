import manager
import receptionist
import accountant
import housekeeping

def setup_files():
    try:
        f = open("rooms.txt", "x")
        f.write("R001,Single,150,available\n")
        f.write("R002,Single,150,available\n")
        f.write("R003,Double,250,available\n")
        f.write("R004,Double,250,available\n")
        f.write("R005,Suite,500,available\n")
        f.close()
    except:
        pass

    for filename in ["guests.txt", "bookings.txt", "payments.txt", "cleaning.txt"]:
        try:
            f = open(filename, "x")
            f.close()
        except:
            pass

def login():
    print("====================================")
    print("   Welcome to StayEase Hotel System")
    print("====================================")
    print()

    username = input("Enter username: ")
    password = input("Enter password: ")

    if username == "manager" and password == "pass123":
        print("\nLogin successful! Welcome, Manager.")
        return "manager"
    elif username == "receptionist" and password == "pass123":
        print("\nLogin successful! Welcome, Receptionist.")
        return "receptionist"
    elif username == "accountant" and password == "pass123":
        print("\nLogin successful! Welcome, Accountant.")
        return "accountant"
    elif username == "housekeeping" and password == "pass123":
        print("\nLogin successful! Welcome, Housekeeping.")
        return "housekeeping"
    else:
        print("\nWrong username or password!")
        return None

setup_files()
role = login()

if role == "manager":
    manager.start()
elif role == "receptionist":
    receptionist.start()
elif role == "accountant":
    accountant.start()
elif role == "housekeeping":
    housekeeping.start()
elif role == None:
    print("Access denied. Please restart the program.")