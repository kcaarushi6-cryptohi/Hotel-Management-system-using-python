def start():
    while True:
        print()
        print("====================================")
        print("       HOUSEKEEPING MENU")
        print("====================================")
        print("1. View Rooms That Need Cleaning")
        print("2. Mark Room as Clean")
        print("3. Report a Maintenance Issue")
        print("4. View Maintenance Issues")
        print("0. Logout")
        print("====================================")

        choice = input("Enter your choice: ")

        if choice == "1":
            view_cleaning_tasks()
        elif choice == "2":
            mark_room_clean()
        elif choice == "3":
            report_issue()
        elif choice == "4":
            view_issues()
        elif choice == "0":
            print("Logged out. Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")

def view_cleaning_tasks():
    print()
    print("---- Rooms That Need Cleaning ----")
    f = open("cleaning.txt", "r")
    tasks = f.readlines()
    f.close()
    if len(tasks) == 0:
        print("No rooms need cleaning right now. Good job!")
        return
    count = 0
    for task in tasks:
        parts = task.strip().split(",")
        if parts[1] == "needs_cleaning":
            print("Room", parts[0], "- needs cleaning")
            count = count + 1
    if count == 0:
        print("All rooms are already clean!")
    else:
        print()
        print("Total rooms to clean:", count)

def mark_room_clean():
    print()
    print("---- Mark Room as Clean ----")
    view_cleaning_tasks()
    room_id = input("\nEnter Room ID that is now clean (e.g. R001): ")
    f = open("cleaning.txt", "r")
    tasks = f.readlines()
    f.close()
    new_tasks = []
    found = False
    for task in tasks:
        parts = task.strip().split(",")
        if parts[0] == room_id:
            found = True
            parts[1] = "clean"
            new_tasks.append(",".join(parts) + "\n")
        else:
            new_tasks.append(task)
    if found == False:
        print("Room ID not found in cleaning list.")
        return
    f = open("cleaning.txt", "w")
    f.writelines(new_tasks)
    f.close()
    f = open("rooms.txt", "r")
    rooms = f.readlines()
    f.close()
    new_rooms = []
    for room in rooms:
        parts = room.strip().split(",")
        if parts[0] == room_id:
            parts[3] = "available"
            new_rooms.append(",".join(parts) + "\n")
        else:
            new_rooms.append(room)
    f = open("rooms.txt", "w")
    f.writelines(new_rooms)
    f.close()
    print("Room", room_id, "marked as clean and is now available for new guests.")

def report_issue():
    print()
    print("---- Report Maintenance Issue ----")
    f = open("rooms.txt", "r")
    rooms = f.readlines()
    f.close()
    print("Rooms:")
    for room in rooms:
        parts = room.strip().split(",")
        print("  Room:", parts[0], "| Type:", parts[1], "| Status:", parts[3])
    room_id = input("\nEnter Room ID with the issue: ")
    issue = input("Describe the issue: ")
    if issue == "":
        print("Issue description cannot be empty.")
        return
    try:
        f = open("maintenance.txt", "r")
        existing = f.readlines()
        f.close()
    except:
        existing = []
    issue_number = len(existing) + 1
    issue_id = "ISS" + str(issue_number).zfill(3)
    new_line = issue_id + "," + room_id + "," + issue + ",pending\n"
    f = open("maintenance.txt", "a")
    f.write(new_line)
    f.close()
    print("Issue", issue_id, "reported for Room", room_id, ". Staff will be notified.")

def view_issues():
    print()
    print("---- Maintenance Issues ----")
    try:
        f = open("maintenance.txt", "r")
        issues = f.readlines()
        f.close()
    except:
        print("No maintenance file found yet.")
        return
    if len(issues) == 0:
        print("No maintenance issues reported.")
        return
    for issue in issues:
        parts = issue.strip().split(",")
        print("Issue:", parts[0], "| Room:", parts[1], "| Problem:", parts[2], "| Status:", parts[3])